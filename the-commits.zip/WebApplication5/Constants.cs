﻿using System.Collections.Generic;

namespace WebApplication5
{
    public static class Constants
    {
        public static string CandidateId = "b8e5cbe3-1dfa-427e-af22-99249b767e5b";
        public static List<long> FibonacciList { get; set; }
    }
}