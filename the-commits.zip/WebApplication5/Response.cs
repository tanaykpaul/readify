﻿namespace Readify
{
    public class Response
    {
        public ResponseCode Code { get; set; }
        public Result Result { get; set; }
    }
}