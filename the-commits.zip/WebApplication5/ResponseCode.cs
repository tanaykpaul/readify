﻿namespace Readify
{
    public enum ResponseCode
    {
        Ok = 200,
        BadReq = 400
    }
}