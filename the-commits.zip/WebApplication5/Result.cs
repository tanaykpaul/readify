﻿namespace Readify
{
    public class Result
    {
        public string Input { get; set; }
        public string Output { get; set; }
    }
}